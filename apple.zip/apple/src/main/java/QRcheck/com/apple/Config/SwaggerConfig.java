package QRcheck.com.apple.Config;

public class SwaggerConfig {
    //In case Swagger Needed.
}
